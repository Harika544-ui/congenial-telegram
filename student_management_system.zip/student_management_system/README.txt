STUDENT MANAGEMENT SYSTEM

A Java Spring Boot starter project with a dashboard and student directory UI.

Requirements:
- Java 17 or newer
- Maven

Run:
1. Open this folder in IntelliJ IDEA or VS Code.
2. From a terminal in this folder, run: mvn spring-boot:run
3. Open your browser at: http://localhost:8080

The dashboard demo uses browser-side sample data. Student additions, edits and deletions are temporary and reset when the page is refreshed. A database-backed persistence layer can be added as a next step.
